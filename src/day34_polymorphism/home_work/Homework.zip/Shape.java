package day34_polymorphism.home_work;

public abstract class Shape {
    public abstract double calculateArea();
}
