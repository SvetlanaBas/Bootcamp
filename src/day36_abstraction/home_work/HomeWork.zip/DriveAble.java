package day36_abstraction.home_work;

public interface DriveAble {
        void drive(double distance);
    }
