package day36_abstraction.home_work;

public interface ChargeAble {
    void charge(double hours);
}
